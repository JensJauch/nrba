function  [xf,xnp,xlp,Pp_k] = fnc_MPF(yNow,NrPart,xnp,xlp,Pp_k,...
    AL,AN,C,uL,uN,QL,QN,R,J)
    % Implementation of the marginalized particle filter derived from
    % http://user.it.uu.se/~thosc112/research/rao-blackwellized-particle.html
    % Thomas Sch�n, Fredrik Gustafsson, and Per-Johan Nordlund. Marginalized 
    % Particle Filters for Mixed Linear/Nonlinear State-Space Models. IEEE 
    % Transactions on Signal Processing, 53(7):2279-2289, Jul. 2005
    
    % and adapted to new formulation described in 
    % G. Hendeby and R. Karlsson and F. Gustafsson: A New Formulation of the 
    % Rao-Blackwellized Particle Filter, 2007 IEEE/SP 14th Workshop on 
    % Statistical Signal Processing, pp. 84-88, Aug. 2007
	% DOI: 10.1109/SSP.2007.4301223
    
    % xf           A posteriori state estimate
    % xnp:         Nonlinear state particles
    % xlp:         Conditionally linear Gaussian state particles
    % Pp_k:        Covariance matrix of a priori estimation error for
    % linear states
    % yNow:        Measurement vector
    % NrPart:      Number of particles
    % AL:          State transition matrix for linear states
    % AN:          State transition matrix for nonlinear states
    % C:           Measurement matrix
    % uL:          Input vector for linear states
    % uN:          Input vector for nonlinear states
    % QL:          Covariance matrix of process noise for linear states
    % QN:          Covariance matrix of process noise for nonlinear states
    % R:           Diagonal matrix with the reciprocals of the relative 
    % weights between the different target criterions for the approximating 
    % J:           Dimension of state vector

    % Particle filter measurement update
    yhat = zeros(size(yNow,1),NrPart);
    for i=1:NrPart
        % Evaluate particles
        yhat(:,i)  = C*xlp(:,i)+[zeros(3,1);fnc_MPF_nonLinModelFnc(C(1,:),xnp(:,i))];
    end
    
    e = zeros(4,NrPart);
    for i=1:NrPart
        % Compute errors
        e(:,i) = yNow-yhat(:,i);
    end
    
    % Compute and normalize the importance weights
    S = C*Pp_k*C' + R(1:4,1:4);
    q = zeros(1,NrPart);
    for i=1:NrPart
      q(i) = exp(-(1/2)*(e(:,i)'/S*e(:,i)));
    end;
    q(1:NrPart) = q(1:NrPart)/sum(q(1:NrPart)); % Normalize the importance weights
     
    % Kalman filter measurement update 
    xlf = zeros(size(xlp));
    for i = 1:NrPart
        xlf(:,i)  = xlp(:,i) + Pp_k*C'/S*e(:,i);
    end;
    Pf_k = Pp_k - Pp_k*C'/S*C*Pp_k;
    
    % Resampling
    index = zeros(1,NrPart);
    index(1:NrPart)   = sysresample(q(1:NrPart)); 
    xlf(:,1:NrPart)     = xlf(:,index(1:NrPart)); % Resampled linear particles 
    
    xf = mean(xlf(:,1:NrPart),2); % State estimate

    % Kalman filter time update
    xi = zeros(size(xnp));
    for i = 1:NrPart
        xi(:,i)  = AN*xlf(:,i) + uN;
        xlp(:,i)  = AL*xlf(:,i) + uL;
    end;
    Pp_k = AL*Pf_k*AL'+QL;
    Pp_xi = AN*Pf_k*AN'+QN;
    Pp_xik = AN*Pf_k*AL';
    Pp_kxi = AL*Pf_k*AN';

   % Particle filter time update
    sigma = real(sqrtm(Pp_xi)); 
    for i = 1:NrPart
        xnp(:,i) = xi(:,i) + sigma*randn(J,1);
    end
    
    % Mixing step, update Kalman filter
    correctionGain = Pp_kxi/Pp_xi;
    for i = 1:NrPart
        xlp(:,i) = xlp(:,i) + correctionGain*(xnp(:,i)-xi(:,i));
    end
    Pp_k = Pp_k - correctionGain*Pp_xik;  
end