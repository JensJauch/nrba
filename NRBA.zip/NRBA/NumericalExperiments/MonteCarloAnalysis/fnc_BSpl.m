function b = fnc_BSpl(k,mu,x,d,r)
% This function returns a B-spline vector b that is needed to evaluate the 
% r-th derivative of a B-spline function of degree d>=1 in the 
% interval [k(mu),k(mu+1)), where k denotes a knot vector. 
%
% The calculation is performed as described in
% T. Lyche and K. Morken, Spline Methods Draft, Department of Informatics,
% Centre of Mathematics for Applications, University of Oslo, 2008.
%
% b: Row vector of B-splines
% k: Knot vector of B-spline function
% x: Independent variable of B-spline function
% d: Degree of B-spline function
% r: Order of derivative of B-spline function

if(r<=d)
    % B-spline vector b is initialized with b = d!/(d-r)!
    b = prod(1:d)/prod(1:d-r); 
    for dInd = 1:d
        % Matrix R holds B-spline matrices B or their derivatives B'
        R = zeros(dInd,dInd+1); 
        for i=1:dInd
            if(dInd<=d-r) % Compute B
                R(i,i) = (k(mu+i)-x)/(k(mu+i)-k(mu-(dInd-i)));
                R(i,i+1) = (x-k(mu-(dInd-i)))/(k(mu+i)-k(mu-(dInd-i)));
            else % Compute B'
                R(i,i) = -1/(k(mu+i)-k(mu-(dInd-i)));
                R(i,i+1) = 1/(k(mu+i)-k(mu-(dInd-i)));
            end
        end
    b = b*R;
    end
else % For r>d, b will be a zero vector
    b = zeros(1,d+1);
end   
end