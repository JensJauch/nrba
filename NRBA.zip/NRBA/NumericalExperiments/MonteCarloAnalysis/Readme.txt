Run NRBAMonteCarloAnalysis to perform an approximation of data points by B-spline functions whose coefficients are 
determined using the algorithm for nonlinear recursive B-Spline approximation (NRBA) 
in comparison with the solution determined by the Levenberg-Marquardt (LM) 
method within a Monte Carlo analysis as described in

% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).

Some information about the attached MATLAB files and functions:

NRBAMonteCarloAnalysis is a script file in which
various parameters for the approximation can be changed, e.g.:
- The data points (s_p,y_p),p=1,2,...,P that are approximated by B-spline functions
- The desired distance intLength between two neighboring knots of the B-spline knot vector
- The degree d of the B-spline function
- The reciprocals of relative weights of different target criteria for the approximating function determined by NRBA and LM
  which are "f close to data points", "f' close to zero", "f'' close to zero" and "c(f) close to zero". c denotes the nonlinear measurement function
- The number of spline intervals I of the B-spline function in which NRBA can adapt the B-spline function simultaneously

Parameters that can be varied during the Monte Carlo analysis are
- The reciprocals of relative weights
- The number of spline intervals
- The number of particles

Additionally some parameters that are held constant during the Monte Carlo analysis are specified.

The number of performed approximation runs for each combination of 
- Reciprocals of relative weights
- Number of spline intervals
- Number of particles
are specified.

The script  NRBAMonteCarloAnalysis invokes the functions
- fnc_InitResultsStruct
- fnc_calculate.m
- fnc_performanceCriterion
- fnc_AugmentResultsStruct
- fnc_performanceCriterionEvaluation
- fnc_plotConvergence
- fnc_plotAndSaveMonteCarloExperiments

fnc_InitResultsStruct initializes a struct in which the results of the Monte Carlo analysis are saved.

fnc_calculate performs the approximations and returns the result. 

fnc_performanceCriterion evaluates the approximating functions according to LM and 
NRBA and returns the performance criterion of the NRBA result compared to the 
approximating function according to LM.

fnc_AugmentResultsStruct augments the struct, in which the results of the Monte Carlo
analysis are saved, with the results of the latest NRBA run

fnc_performanceCriterionEvaluation evaluates the performance criterion values of all runs with 
same setting and determines the minimum, 5% quantile, 10% quantile, median, 
90% quantile, 95% quantile and maximum of the performance criterion values as well as the number
of the run that achieves the corresponding value. 

fnc_plotConvergence plots the minimum, median and maximum of the performance 
criterion versus the particle count for each combination of weighting 
setting and number of spline intervals. The function also saves the plot data in txt files.

fnc_plotAndSaveMonteCarloExperiments selects data from the results struct and prepares it for
plotting by the function fnc_plot_MC. It also saves the plot data in txt files.

fnc_plot_MC plots the data, the knot vector and the approximation functions determined by LM and NRBA.

fnc_calculate.m contains the following functions:
- fnc_calculate performs an approximation using LM followed by approximations using
	NRBA with different parameter settings
- fnc_LM implements the Levenberg-Marquardt method and calls fnc_nlsqfun
- fnc_nlsqfun computes the weighted error vector for the current LM solution and calls fnc_bMat
- fnc_bMat returns a matrix containing values of B-splines

fnc_NRBA performs a single iteration of NRBA as described in Algorithm 2 of [1] and calls fnc_MPF

fnc_MPF implements the marginalized particle filter as described in Algorithm 1 of [1]

fnc_BSpl returns a B-spline vector and is called by both fnc_calculate and fnc_plot

The files have been tested under MATLAB R2015b 64bit. 
Please let me know if you find bugs or need any help (jens.jauch@kit.edu).