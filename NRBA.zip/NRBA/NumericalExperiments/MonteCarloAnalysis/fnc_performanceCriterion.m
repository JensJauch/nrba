function [perfCrit,yLM,yNRBA] = fnc_performanceCriterion(s,d,cNRBA,cLM,k)
% This function evaluates the approximating functions according to LM and 
% NRBA and returns the performance criterion of the NRBA result compared
% to the approximating function according to LM.
%
% perfCrit: Value of performance criterion for latest run
% yLM:      Values of function determined by LM
% yNRBA:    Values of function determined by NRBA
% s:        Vector of supporting points s_p of data points (s_p,y_p)
% d:        Degree of B-spline function
% cNRBA:    B-spline coefficients determined using NRBA
% cLM:      B-spline coefficients determined using LM
% k:        Knot vector of B-spline aproximation functions

yLM = zeros(size(s));
yNRBA = zeros(size(s));
% Iterate through set of data points
for p=1:size(s,2)
    % Determine B-spline vector for s_p
    mu = find(k<=s(p),1,'last');
    b = fnc_BSpl(k,mu,s(p),d,0);
    % Evaluate approximating functions according to LM and NRBA
    yLM(p) = b*cLM(mu-d:mu,1);
    yNRBA(p) = b*cNRBA(mu-d:mu,1);
end
% Calculate performance criterion (normalized root mean square error)
MSE = sum((yLM'-yNRBA').^2)/length(yLM);
perfCrit = sqrt(MSE)/(max(yLM) - min(yLM));
end