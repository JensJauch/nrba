function RESULTS = fnc_InitResultsStruct(weightingSet,ISet,nrPartSet,nrRuns,s,y,d)
% This function initializes the struct RESULTS in which the results of the 
% Monte Carlo analysis are saved.
%
% RESULTS:      Struct that holds Monte Carlo analysis results
% weightingSet: Vector of weighting vectors
% ISet:         Vector of numbers of spline intervals
% nrPartSet:    Vector of particle counts 
% nrRuns:       Number of NRBA approximation runs for each combination
% of the entries of the vectors weightingSet, ISet and nrPartSet
% s:            Vector of supporting points s_p of data points (s_p,y_p)
% y:            Vector of values y_p of data points (s_p,y_p)
% d:            Degree of B-spline function

RESULTS.weightingSet = weightingSet;
RESULTS.ISet = ISet;
RESULTS.nrPartSet = nrPartSet;
RESULTS.nrRuns = nrRuns;
RESULTS.s = s;
RESULTS.y = y;
RESULTS.d = d;
end