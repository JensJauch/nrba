% Function for resampling in the marginalized particle filter from    
% http://user.it.uu.se/~thosc112/research/rao-blackwellized-particle.html
% Thomas Sch�n, Fredrik Gustafsson, and Per-Johan Nordlund. Marginalized 
% Particle Filters for Mixed Linear/Nonlinear State-Space Models. IEEE 
% Transactions on Signal Processing, 53(7):2279-2289, Jul. 2005

function i=sysresample(q)
qc=cumsum(q);    M=length(q);
u=([0:M-1]+rand(1))/M;
i=zeros(1,M);    k=1;
for j=1:M
  while (qc(k)<u(j) && k<M)
    k=k+1;
  end
  i(j)=k;
end
end