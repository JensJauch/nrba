function fnc_plotConvergence(RESULTS,PLOTSETTINGS)
% This function plots the minimum, median and maximum of the performance 
% criterion versus the particle count for each combination of weighting 
% setting and number of spline intervals. The function also saves the plot 
% data in txt files.
%
% RESULTS:      Struct that holds Monte Carlo analysis results
% PLOTSETTINGS: Struct that holds plot settings

Colors = {'green','blue','black','red','cyan','magenta','yellow'};
LineStyles = {'-','--','-.',':'};
MarkerType = {'o','+','*','.'};
figure('Name','Convergence of NRBA solution to LM solution')
hold all
weightingSet = RESULTS.weightingSet;
ISet = RESULTS.ISet;
nrPartSet = RESULTS.nrPartSet;

plotNrPart = zeros(1,size(nrPartSet,2));
plotperfCritMin = zeros(size(weightingSet,2)*size(ISet,2),size(nrPartSet,2));
plotperfCritMed = zeros(size(weightingSet,2)*size(ISet,2),size(nrPartSet,2));
plotperfCritMax = zeros(size(weightingSet,2)*size(ISet,2),size(nrPartSet,2));
for weightingIt = 1:size(weightingSet,2);
    for ISetIt = 1:size(ISet,2)
        struct = RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]);
        plotNrPart = zeros(size(nrPartSet));
        for nrPartSetIt = 1:size(nrPartSet,2)
            plotNrPart(nrPartSetIt) = struct.(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).(['runID_',num2str(1)]).nrPart;
            plotperfCritMin((weightingIt-1)*size(weightingSet,2)+ISetIt,nrPartSetIt) = struct.(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMin;
            plotperfCritMed((weightingIt-1)*size(weightingSet,2)+ISetIt,nrPartSetIt) = struct.(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMed;
            plotperfCritMax((weightingIt-1)*size(weightingSet,2)+ISetIt,nrPartSetIt) = struct.(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMax;
        end % nrPartSet
        lineColor = Colors{(weightingIt-1)*size(weightingSet,2) + ISetIt};
        plot(plotNrPart,plotperfCritMax((weightingIt-1)*size(weightingSet,2)+ISetIt,:),'DisplayName',...
        ['weighting\_',num2str(weightingSet(weightingIt)),' I\_',num2str(ISet(ISetIt))],...
        'Color',lineColor,'LineStyle',LineStyles{1},'Marker',MarkerType{1});
            plot(plotNrPart,plotperfCritMed((weightingIt-1)*size(weightingSet,2)+ISetIt,:),'DisplayName',...
        ['weighting\_',num2str(weightingSet(weightingIt)),' I\_',num2str(ISet(ISetIt))],...
        'Color',lineColor,'LineStyle',LineStyles{2},'Marker',MarkerType{2});
            plot(plotNrPart,plotperfCritMin((weightingIt-1)*size(weightingSet,2)+ISetIt,:),'DisplayName',...
        ['weighting\_',num2str(weightingSet(weightingIt)),' I\_',num2str(ISet(ISetIt))],...
        'Color',lineColor,'LineStyle',LineStyles{3},'Marker',MarkerType{3});
    end % ISet
end % weightingSet
legend(gca,'show')
set(gcf,'Color','white')
xlabel('Number of particles')
ylabel('Root mean square error')

%% Save plot data in files
str = [pwd,'\',PLOTSETTINGS.settingsString,'\','NRBAexperiment','_convergence'];
fid = fopen(sprintf('%s%s',str,'.txt'),'w');
fprintf(fid,['MinN1\t MinN3\t MinL1\t MinL3\t MedN1\t MedN3\t MedL1\t MedL3\t MaxN1\t MaxN3\t MaxL1\t MaxL3\t nrPart\n']);
fprintf(fid,['%g\t %g\t %g\t %g\t %g\t %g\t %g\t %g\t %g\t %g\t %g\t %g\t  %g\n'],[plotperfCritMin;plotperfCritMed;plotperfCritMax;plotNrPart]);
fclose(fid);
end