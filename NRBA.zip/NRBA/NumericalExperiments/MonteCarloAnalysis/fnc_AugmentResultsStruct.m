function RESULTS = fnc_AugmentResultsStruct(RESULTS,cNRBA,cLM,R_NRBA,R_LM,weightingSet,weightingIt,ISet,ISetIt,nrPartSet,nrPartSetIt,runID,perfCrit,yLM,yNRBA,k)
% This function augments the struct RESULTS, in which the results of the 
% Monte Carlo analysis are saved, with the results of the latest NRBA run
%
% RESULTS:      Struct that holds Monte Carlo analysis results
% cNRBA:        Matrix of B-spline coefficients determined using NRBA with 
% different parameter settings which vary along the columns
% cLM:          B-spline coefficients determined using LM with 
% different parameter settings which vary along the columns
% R_NRBA:       Vector that contains the reciprocals of relative weights 
% between the different target criteria for NRBA
% R_LM:         Vector that contains the reciprocals of relative weights 
% between the different target criteria for LM
% weightingSet: Vector of weighting vectors
% weightingIt:  Component of weightingSet used in the latest run
% ISet:         Vector of numbers of spline intervals
% ISetIt:       Component of ISetIt used in the latest run
% nrPartSet:    Vector of particle counts 
% nrPartSetIt:  Component of nrPartSet used in the latest run
% runID:        Run number of the latest run
% perfCrit:     Value of performance criterion for latest run
% yNRBA:        Matrix of y values of functions determined by NRBA
% yLM:          Matrix of y values of functions determined by LM
% k:            Knot vector of B-spline aproximation functions

struct.cNRBA = cNRBA;
struct.R_NRBA = R_NRBA;
struct.nrPart = nrPartSet(nrPartSetIt);
struct.perfCrit = perfCrit;
struct.yNRBA = yNRBA;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).(['runID_',num2str(runID)]) = struct;

RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).cLM = cLM;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).R_LM = R_LM;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).yLM = yLM;

RESULTS.k = k;
end