function [xHatVecPlus,xlp,xnp,P_plus,knotVec] = fnc_NRBA...
    (knotVecOld,xlp,xnp,P_plusOld,R,s,sOld,yOld,knotVecbar,xbar,pbar,qlbar,qnbar,NrPart)
% This function implements the algorithm for nonlinear recursive B-Spline 
% approximation (NRBA) proposed in
%
% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).
%
% xHatVecPlus:    A posteriori state estimate of current iteration
% xlp:            Conditionally linear Gaussian state particles
% xnp:            Nonlinear state particles
% P_plus:         Covariance matrix of a posteriori estimation error of
% current iteration
% knotVec:        Knot vector of current iteration
% knotVecOld:     Knot vector of previous iteration
% xVecHatPlusOld: A posteriori state estimate of previous iteration
% P_plusOld:      Covariance matrix of a posteriori estimation error of
% previous iteration
% R:              Diagonal matrix with the reciprocals of the relative 
% weights between the different target criterions for the approximating 
% B-spline function
% s:              Supporting point s_p of data point (s_p,y_p)
% sOld:           Supporting point s_{p-1} of data point (s_{p-1},y_{p-1})
% yOld:           Value y_{p-1} of data point (s_{p-1},y_{p-1})
% knotVecbar:     Knot vector that contains additional knots needed for a
% shift operation 
% xbar:           Initial estimate for spline coefficients
% pbar:           Initial value for elements on the main diagonal of 
% the covariance matrix of a posteriori error P_plus
% qlbar:          Value for elements on the main diagonal of the 
% covariance matrix of process noise Ql for linear states
% qnbar:          Value for elements on the main diagonal of the 
% covariance matrix of process noise Qn for nonlinear states
% NrPart:         Number of particles

J = size(xlp,1); % Number of B-splines
K = size(knotVecOld,2); % Number of knots
d = K-J-1; % Degree of the B-spline function

% Computation of sigma
sigma = 0;
if(s>=knotVecOld(J+1))
    if(s>=knotVecOld(K))
        sigma = d+1;
    else
        sigma = find(knotVecOld<=s,1,'last')-J;
    end
elseif(s<knotVecOld(d+1))
    if(s<knotVecOld(1))
        sigma = -(d+1);
    else
        sigma = find(knotVecOld<=s,1,'last')-(d+1);
    end
end
% Computation of transition matrix for linear states AL and transition 
% matrix for nonlinear states AN
AL = zeros(J,J);
for i=1:J
    for j=1:J
        if(j==i+sigma)
            AL(i,j) = 1;
        end
    end
end
AN=AL;

% Initialize the covariance matrix of linear process noise QL and
% covariance matrix of nonlinear process noise QN
QL = qlbar*eye(J,J);
QN = qnbar*eye(J,J);

if(sigma>=0) % Right shift of the definition range of the B-spline function
    knotVec = [knotVecOld(sigma+1:K),knotVecbar(K-sigma+1:K)];
    u = [zeros(J-sigma,1);xbar*ones(sigma,1)];
    for i=J-sigma+1:J
        QL(i,i) = pbar;
        QN(i,i) = pbar;
    end
else % Left shift of the definition range of the B-spline function
    knotVec = [knotVecbar(1:-sigma),knotVecOld(1:K+sigma)];
    u = [xbar*ones(-sigma,1);zeros(J+sigma,1)];
    for i=1:-sigma
        QL(i,i) = pbar;
        QN(i,i) = pbar;
    end
end
uL = u; % Input vector for linear states
uN = u; % Input vector for nonlinear states

% Compute the index mu of the spline interval to which s belongs
muOld = find(knotVecOld<=sOld,1,'last');

% Compute the measurement matrix
calC = [zeros(3,muOld-d-1),[fnc_BSpl(knotVecOld,muOld,sOld,d,0);...
    fnc_BSpl(knotVecOld,muOld,sOld,d,1);fnc_BSpl(knotVecOld,muOld,sOld,d,2)],zeros(3,J-muOld)]; 

% Update covariance matrix
Pp = P_plusOld;

% Perform a marginalized particle filter iteration
 [xf,xnp,xlp,Pp]= fnc_MPF(yOld,NrPart,xnp,xlp,Pp,...
    AL,AN,[calC(1:3,:);zeros(1,J)],uL,uN,QL,QN,R,J);

% Update estimated state vector
xHatVecPlus = xf;

% Update covariance matrix
P_plus = Pp;
end