function RESULTS = fnc_performanceCriterionEvaluation(RESULTS,weightingIt,ISetIt,nrPartSetIt)
% This function evaluates the performance criterion values of all runs with 
% same setting and determines the minimum, 5% quantile, 10% quantile, median, 
% 90% quantile, 95% quantile and maximum of the performance criterion values
% as well as the number of the run that achieves the corresponding value. 
%
% RESULTS:      Struct that holds Monte Carlo analysis results
% weightingIt:  Component of vector of weighting vectors used in the runs
% ISetIt:       Component of vector of numbers of spline intervals used in
% the runs
% nrPartSetIt:  Component of vector of particle counts used in the runs

weightingSet = RESULTS.weightingSet;
ISet = RESULTS.ISet;
nrPartSet = RESULTS.nrPartSet;
nrRuns = RESULTS.nrRuns;

struct = RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]);
performanceCritArray = zeros(1,nrRuns);
for runID = 1:nrRuns
    performanceCritArray(runID) = struct.(['runID_',num2str(runID)]).perfCrit;
end
[perfCritMin,perfCritMinID] = min(performanceCritArray);
[perfCritMax,perfCritMaxID] = max(performanceCritArray);

[performanceCritArraySorted,indices] = sort(performanceCritArray,2,'ascend');

perfCritQuant05 = quantile(performanceCritArray,0.05);
perfCritQuant05IDSorted = find(performanceCritArraySorted>=perfCritQuant05,1,'first');
perfCritQuant05ID = indices(perfCritQuant05IDSorted);
perfCritQuant05 = struct.(['runID_',num2str(perfCritQuant05ID)]).perfCrit;

perfCritQuant10 = quantile(performanceCritArray,0.1);
perfCritQuant10IDSorted = find(performanceCritArraySorted>=perfCritQuant10,1,'first');
perfCritQuant10ID = indices(perfCritQuant10IDSorted);
perfCritQuant10 = struct.(['runID_',num2str(perfCritQuant10ID)]).perfCrit;

perfCritMed = quantile(performanceCritArray,0.5);
perfCritMedIDSorted = find(performanceCritArraySorted>=perfCritMed,1,'first');
perfCritMedID = indices(perfCritMedIDSorted);
perfCritMed = struct.(['runID_',num2str(perfCritMedID)]).perfCrit;

perfCritQuant90 = quantile(performanceCritArray,0.9);
perfCritQuant90IDSorted = find(performanceCritArraySorted>=perfCritQuant90,1,'first');
perfCritQuant90ID = indices(perfCritQuant90IDSorted);
perfCritQuant90 = struct.(['runID_',num2str(perfCritQuant90ID)]).perfCrit;

perfCritQuant95 = quantile(performanceCritArray,0.95);
perfCritQuant95IDSorted = find(performanceCritArraySorted>=perfCritQuant95,1,'first');
perfCritQuant95ID = indices(perfCritQuant95IDSorted);
perfCritQuant95 = struct.(['runID_',num2str(perfCritQuant95ID)]).perfCrit;

RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMin = perfCritMin;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMinID = perfCritMinID;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMax = perfCritMax;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMaxID = perfCritMaxID;     
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMed = perfCritMed;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritMedID = perfCritMedID;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant05 = perfCritQuant05;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant05ID = perfCritQuant05ID;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant10 = perfCritQuant10;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant10ID = perfCritQuant10ID;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant90 = perfCritQuant90;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant90ID = perfCritQuant90ID;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant95 = perfCritQuant95;
RESULTS.(['weighting_',num2str(weightingSet(weightingIt))]).(['I_',num2str(ISet(ISetIt))]).(['nrPart_',num2str(nrPartSet(nrPartSetIt))]).perfCritQuant95ID = perfCritQuant95ID;
end