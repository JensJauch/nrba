function  Value = fnc_MPF_nonLinModelFnc(b,c)
% This function implements the nonlinear measurement function that depends
% on the value of the approximation function
%
% Value:    Value of measurement function
% b:        B-spline vector of approximating function
% c:        Coefficient vector of approximating function

% Parameters of quadratic B-spline function that serves as nonlinear
% measurement function and depends on the value of the approximating
% B-spline function
d_nlfun = 2; % Degree
c_nlfun = [0;0;0;0.25;1.5;5;5;0;0;6;8;8;8]; % Coefficient vector
k_nlfun = 5*(-3:12)+10; % Knot vector

Val_approx_function = b*c; % Value of approximating B-spline function

% Restrict evaluation point of nonlinear measurement function to its
% definition range
s = max(k_nlfun(d_nlfun+1),min(Val_approx_function,k_nlfun(end-d_nlfun)-1e-3));

mu = find(k_nlfun<=s,1,'last'); % Determine spline interval for evaluation point

% Value of nonlinear measurement function
Value = fnc_BSpl(k_nlfun,mu,s,d_nlfun,0)*c_nlfun(mu-d_nlfun:mu);

end