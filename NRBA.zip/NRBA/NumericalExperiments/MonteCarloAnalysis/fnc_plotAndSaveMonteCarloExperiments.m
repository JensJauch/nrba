function fnc_plotAndSaveMonteCarloExperiments(RESULTS,PLOTSETTINGS)
% This function selects data from the results struct and prepares it for
% plotting by the function fnc_plot_MC. It also saves the plot data in txt files.
%
% RESULTS:      Struct that holds Monte Carlo analysis results
% PLOTSETTINGS: Struct that holds plot settings

s = RESULTS.s;
y = RESULTS.y;
d = RESULTS.d;
k = RESULTS.k;

nrPartSet = PLOTSETTINGS.NRBAplot.nrPart;
ISet = PLOTSETTINGS.NRBAplot.I;
weightingNRBA = PLOTSETTINGS.NRBAplot.weighting;
perfCrit = PLOTSETTINGS.NRBAplot.perfCrit;
weightingLM = PLOTSETTINGS.LMplot.weighting;
resolution = PLOTSETTINGS.resolution;

% % Legend entries for plots
PLOTSETTINGS.NRBAlegend = {['NRBA I=',sprintf('%i',ISet(1)),' P=',sprintf('%i',nrPartSet(1))],...
    ['NRBA I=',sprintf('%i',ISet(2)),' P=',sprintf('%i',nrPartSet(2))],...
    ['NRBA I=',sprintf('%i',ISet(3)),' P=',sprintf('%i',nrPartSet(3))],...
    ['NRBA I=',sprintf('%i',ISet(4)),' P=',sprintf('%i',nrPartSet(4))]};

for i = 1:size(ISet,2)
    runID = RESULTS.(['weighting_',weightingNRBA(i)]).(['I_',num2str(ISet(i))]).(['nrPart_',num2str(nrPartSet(i))]).(['perfCrit',perfCrit{i},'ID']);
    cNRBA(:,i) = RESULTS.(['weighting_',weightingNRBA(i)]).(['I_',num2str(ISet(i))]).(['nrPart_',num2str(nrPartSet(i))]).(['runID_',num2str(runID)]).cNRBA;
end

for i=1:2
    cLM(:,i) = RESULTS.(['weighting_',weightingLM(i)]).cLM(:,i);
end

%% Plot results
[yplotNRBAVariants,yplotLM,uplot]= fnc_plot_MC(s,y,d,k,cNRBA,cLM,...
    resolution,PLOTSETTINGS);

%% Save plot data in files
str = [pwd,'\',PLOTSETTINGS.settingsString,'\','NRBAexperiment',num2str(PLOTSETTINGS.experimentNumber),'_approximations'];
fid = fopen(sprintf('%s%s',str,'.txt'),'w');
fprintf(fid,['yNRBA1\t yNRBA2\t yNRBA3\t yNRBA4\t yLM1\t yLM2\t s\n']);
fprintf(fid,['%g\t %g\t %g\t %g\t %g\t %g\t %g\n'],[yplotNRBAVariants;yplotLM;uplot]);
fclose(fid);
str = [pwd,'\',PLOTSETTINGS.settingsString,'\','NRBAexperiment',num2str(PLOTSETTINGS.experimentNumber),'_datapoints'];
fid = fopen(sprintf('%s%s',str,'.txt'),'w');
fprintf(fid,'y\t s\n');
fprintf(fid,'%g\t %g\n',[y;s]);

end