% This script performs the approximation of data points with B-spline
% functions whose coefficients are determined by nonlinear recursive B-spline 
% approximation (NRBA) within a Monte Carlo analysis as described in

% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).

%% Generate a set of data points (s_p,y_p_1), c.f. subsection 3.1 of [1]
s = 0.25:0.5:199.75;
y=[];
for p=1:size(s,2) 
    if (s(p)>=80 && s(p)<120)
        y = [y,40];
    else
        y =[y,30];
    end
end

%% Parameters for B-spline function f(s)
d = 3; % degree of the B-spline function, d>=1
% Desired interval length (>0), i.e. distance between two neighboring
% knots. If the set of data points is chosen such that a shift operation by
% more than d+1 elements has to be performed, the knots of the knot vector 
% computed in fnc_calculate will not be equidistant.
intLength = 10;

%% Parameters for nonlinear recursive B-spline approximation (NRBA)
%% that will be varied during the Monte Carlo analysis
% weightingSet is a vector whose entries denote weighting vectors that will
% be used. L denotes the weighting vector for the quasi-linear approximation 
% problem and N the weighting vector for the nonlinear approximation problem.
weightingSet = ['N','L']; % L | N
% ISet is a vector that contains different numbers of spline intervals I.
ISet = [1,3];
% nrPartSet is a vector that contains different numbers of particles nrPart. 
nrPartSet = [9,13,16,64,81,256,625,729,1296,2401,4096,6561,15625];

%% Parameters for nonlinear recursive B-spline approximation (NRBA)
%% that will not be varied during the Monte Carlo analysis
% IStart denotes the spline interval to which the first data point will belong. 
% IStart=1 is the first spline interval and IStart=I the last spline interval.
% IStart=1,2,...,I corresponds to mu = d+1,...,J with J=d+I in [1].
IStart = 1;
% xbar is the initial value for estimated spline coefficients. For xbar=NaN, 
% xbar equals y_p_1 or a current coefficient estimate
xbar = NaN; 
% pbar is the initial value for the main diagonal of the covariance matrix 
% of a posteriori error P_plus
pbar = 30;
% qlbar is the value for the main diagonal elements of the 
% covariance matrix of linear process noise Ql
qlbar = 5e-3;
% qnbar is the value for the main diagonal elements of the 
% covariance matrix of linear process noise Qn
qnbar = 0.25;

%% Monte Carlo analysis settings
% nrRuns denotes the number of NRBA approximation runs for each combination
% of the entries of the vectors weightingSet, ISet and nrPartSet. In [1] 
% nrRuns = 50 was used. For less computation time it is set to 10 here.
nrRuns = 10;
% String of parameters that are constant during the Monte Carlo analysis,
% used for titles, folder and file names
settingsString = ['P_',num2str(pbar),'_QL',num2str(qlbar),'_QN',num2str(qnbar)];
% Create folder for results
mkdir(settingsString);
% Initialize struct for results of computations
RESULTS = fnc_InitResultsStruct(weightingSet,ISet,nrPartSet,nrRuns,s,y,d);
% Enable log of console output and save log at specified destination
diary([pwd,'\',settingsString,'\','ConsoleOutput_',settingsString,'.txt']);

for weightingIt = 1:size(weightingSet,2);
    for ISetIt = 1:size(ISet,2)
        for nrPartSetIt = 1:size(nrPartSet,2)
            for runID = 1:nrRuns

                % Diagonal matrix with the reciprocals of the relative weights between the
                % different target criteria for the approximating B-spline function f(s),
                % on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
                % zero, f'' close to zero, c(f) close to zero]. c denotes the nonlinear
                % measurement function
                if (isequal(weightingSet(weightingIt),'L'))
                    R_NRBA = [1e0,5e-2,5e-3,1e6];
                else
                    R_NRBA = [1e0,5e-2,5e-3,8e-1];
                end
                %% Parameters for Levenberg-Marquardt (LM) algorithm
                % Diagonal matrix with the reciprocals of the relative weights between the
                % different target criteria for the approximating B-spline function f(s),
                % on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
                % zero, f'' close to zero, c(f) close to zero]. c denotes the nonlinear
                % measurement function
                R_LM = [R_NRBA;R_NRBA];
                % LM needs to be performed only once for each weighting
                % vector, which is achieved by the following lines
                if(ISetIt==1 && nrPartSetIt==1 && runID==1)
                    performLM = true;
                else
                    performLM = false;
                end
                %% Display time, number and setting of current NRBA run
                disp([datestr(datetime('now')),' weighting_',num2str(weightingSet(weightingIt)),' I_',num2str(ISet(ISetIt)),' nrPart_',num2str(nrPartSet(nrPartSetIt)),' runID_',num2str(runID)]);
                %% Perform calculations
                [cNRBA,cLM,k,tNRBA,tLM,printMessage] = fnc_calculate(intLength,s,y,d,...
                    ISet(ISetIt),IStart,xbar,pbar,qlbar,qnbar,R_NRBA,R_LM,nrPartSet(nrPartSetIt),performLM);

                if(performLM)
                    cLMTemp = cLM;
                else
                    cLM = cLMTemp;
                end
                %% Compute values of perforrmance criterion for NRBA run
                [perfCrit,yLM,yNRBA] = fnc_performanceCriterion(s,d,cNRBA,cLM,k);
                %% Add results of latest run to results struct
                RESULTS = fnc_AugmentResultsStruct(RESULTS,cNRBA,cLM,R_NRBA,R_LM,weightingSet,weightingIt,ISet,ISetIt,nrPartSet,nrPartSetIt,runID,perfCrit,yLM,yNRBA,k);
            end % nrRuns
            %% Evaluate performance criterion values of all runs with same setting 
            RESULTS = fnc_performanceCriterionEvaluation(RESULTS,weightingIt,ISetIt,nrPartSetIt);
            
        end % nrPartSet
    end % ISet
end % WeightingSet

% Disable console output log
diary off
% Save workspace for later use of computation results
save([pwd,'\',settingsString,'\','Workspace_',settingsString,'.mat']);

%% Parameters for plot functions
PLOTSETTINGS.settingsString = settingsString;
% Horizontal distance between two neighboring positions where the
% B-splines functions are evaluated
PLOTSETTINGS.resolution = 0.1;

%% Create and save figure of NRBA convergence
fnc_plotConvergence(RESULTS,PLOTSETTINGS);
title(strrep([settingsString,'_Convergence'],'_','\_'));
savefig([pwd,'\',settingsString,'\','Fig_',settingsString,'_Convergence','.fig']);

%% Create and save figures of specified approximation results
PLOTSETTINGS.NRBAplot.nrPart = [6561,6561,6561,6561];
PLOTSETTINGS.NRBAplot.I = [1,1,1,1]; 
PLOTSETTINGS.NRBAplot.weighting = ['L','L','N','N']; % L | N
PLOTSETTINGS.NRBAplot.perfCrit = {'Med','Max','Med','Max'}; % Min | Max | Max | Quant05 | Quant10 | Quant90 | Quant95
PLOTSETTINGS.LMplot.weighting = ['L','N'];
PLOTSETTINGS.experimentNumber = 1;
PLOTSETTINGS.figTitle = strrep([settingsString,'_L6561Med_L6561Max_N6561Med_N6561Max'],'_','\_');
fnc_plotAndSaveMonteCarloExperiments(RESULTS,PLOTSETTINGS);
savefig([pwd,'\',settingsString,'\','Fig_',settingsString,'_L6561Med_L6561Max_N6561Med_N6561Max','.fig']);

PLOTSETTINGS.NRBAplot.nrPart = [625,625,15625,15625];
PLOTSETTINGS.NRBAplot.I = [1,1,3,3]; 
PLOTSETTINGS.NRBAplot.weighting = ['L','L','L','L']; % L | N
PLOTSETTINGS.NRBAplot.perfCrit = {'Med','Max','Med','Max'}; % Min | Max | Max | Quant05 | Quant10 | Quant90 | Quant95
PLOTSETTINGS.LMplot.weighting = ['L','N'];
PLOTSETTINGS.experimentNumber = 2;
PLOTSETTINGS.figTitle = strrep([settingsString,'_L625Med_L625Max_3L15625Med_3L15625Max'],'_','\_');
fnc_plotAndSaveMonteCarloExperiments(RESULTS,PLOTSETTINGS);
savefig([pwd,'\',settingsString,'\','Fig_',settingsString,'_L625Med_L625Max_3L15625Med_3L15625Max','.fig']);

PLOTSETTINGS.NRBAplot.nrPart = [625,625,15625,15625];
PLOTSETTINGS.NRBAplot.I = [1,1,3,3]; 
PLOTSETTINGS.NRBAplot.weighting = ['N','N','N','N']; % L | N
PLOTSETTINGS.NRBAplot.perfCrit = {'Med','Max','Med','Max'}; % Min | Max | Max | Quant05 | Quant10 | Quant90 | Quant95
PLOTSETTINGS.LMplot.weighting = ['L','N'];
PLOTSETTINGS.experimentNumber = 3;
PLOTSETTINGS.figTitle = strrep([settingsString,'_N625Med_N625Max_3N15625Med_3N15625Max'],'_','\_');
fnc_plotAndSaveMonteCarloExperiments(RESULTS,PLOTSETTINGS);
savefig([pwd,'\',settingsString,'\','Fig_',settingsString,'_N625Med_N625Max_3N15625Med_3N15625Max','.fig']);

PLOTSETTINGS.NRBAplot.nrPart = [6561,6561,6561,6561];
PLOTSETTINGS.NRBAplot.I = [3,3,3,3]; 
PLOTSETTINGS.NRBAplot.weighting = ['L','L','N','N']; % L | N
PLOTSETTINGS.NRBAplot.perfCrit = {'Med','Max','Med','Max'}; % Min | Max | Max | Quant05 | Quant10 | Quant90 | Quant95
PLOTSETTINGS.LMplot.weighting = ['L','N'];
PLOTSETTINGS.experimentNumber = 4;
PLOTSETTINGS.figTitle = strrep([settingsString,'_3L6561Med_3L6561Max_3N6561Max_3N6561Max'],'_','\_');
fnc_plotAndSaveMonteCarloExperiments(RESULTS,PLOTSETTINGS);
savefig([pwd,'\',settingsString,'\','Fig_',settingsString,'_3L6561Med_3L6561Max_3N6561Med_3N6561Max','.fig']);