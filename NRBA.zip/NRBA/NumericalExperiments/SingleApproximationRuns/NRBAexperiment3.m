% This script performs an approximation of data points with B-spline
% functions whose coefficients are determined by nonlinear recursive B-spline 
% approximation (NRBA) as described in the subsections 3.2 to 3.4 of

% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).

%% Generate a set of data points (s_p,y_p_1), c.f. subsection 3.1 of [1]
s = 0.25:0.5:199.75;
y=[];
for p=1:size(s,2) 
    if (s(p)>=80 && s(p)<120)
        y = [y,40];
    else
        y =[y,30];
    end
end

%% Parameters for B-spline function f(s)
d = 3; % degree of the B-spline function, d>=1
% Desired interval length (>0), i.e. distance between two neighboring
% knots. If the set of data points is chosen such that a shift operation by
% more than d+1 elements has to be performed, the knots of the knot vector 
% computed in fnc_calculate will not be equidistant.
intLength = 10;

%% Parameters for nonlinear recursive B-spline approximation (NRBA)
% ...Set are vectors whose i-th component is a parameter value that will be 
% used in the i-th run of NRBA.
% ISet is a vector that contains different numbers of spline intervals I.
ISet = [1,1,1,1];
% IStartSet is a vector that contains different values IStart which denote 
% the spline interval to which the first data point will belong. IStart=1 
% is the first spline interval and IStart=I the last spline interval.
% % IStart=1,2,...,I corresponds to mu = d+1,...,J with J=d+I in [1].
IStartSet = [1,1,1,1];
% xbarSet contains different initial values xbar for estimated spline 
% coefficients. For xbar=NaN, xbar equals y_p_1 or a current coefficient
% estimate
xbarSet = [NaN,NaN,NaN,NaN]; 
% pbarSet contains different initial values pbar for the main diagonal of 
% the covariance matrix of a posteriori error P_plus
pbarSet = [30,30,30,30];
% qlbarSet contains different values qlbar for the main diagonal of the 
% covariance matrix of linear process noise Ql
qlbarSet = [5e-3,5e-3,5e-3,5e-3];
% qnbarSet contains different values qbar for the main diagonal of the 
% covariance matrix of nonlinear process noise Qn
qnbarSet = [0.5,0.5,0.5,0.5];
% nrPartSet is a vector that contains different numbers of particles nrPart 
nrPartSet = [4^(ISet(1)+d),6^(ISet(2)+d),8^(ISet(3)+d),9^(ISet(4)+d)]; 
% Diagonal matrix with the reciprocals of the relative weights between the
% different target criteria for the approximating B-spline function f(s),
% on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
% zero, f'' close to zero, c(f) close to zero]. c denotes the nonlinear
% measurement function
R_NRBA = [[1e0,5e-2,5e-3,8e-1];...
          [1e0,5e-2,5e-3,8e-1];...
          [1e0,5e-2,5e-3,8e-1];...
          [1e0,5e-2,5e-3,8e-1]]; 

%% Parameters for Levenberg-Marquardt (LM) algorithm
% Diagonal matrix with the reciprocals of the relative weights between the
% different target criteria for the approximating B-spline function f(s),
% on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
% zero, f'' close to zero, c(f) close to zero]. c denotes the nonlinear
% measurement function
R_LM = [[1e0,5e-2,5e-3,1e6];...
        [1e0,5e-2,5e-3,8e-1]]; 
% The computation time required for LM increases strongly with the number
% of data points and coefficients. The following variable allows to prevent
% applying LM in such cases. 
performLM = true;

%% Parameters for plot function
% Horizontal distance between two neighboring positions where the
% B-splines functions are evaluated
resolution = 0.1;
% Legend entries for plots
NRBAlegend = {['NRBA I=',sprintf('%i',ISet(1)),' P=',sprintf('%i',nrPartSet(1))],...
    ['NRBA I=',sprintf('%i',ISet(2)),' P=',sprintf('%i',nrPartSet(2))],...
    ['NRBA I=',sprintf('%i',ISet(3)),' P=',sprintf('%i',nrPartSet(3))],...
    ['NRBA I=',sprintf('%i',ISet(4)),' P=',sprintf('%i',nrPartSet(4))]};
   
%% Perform calculations
[cNRBA,cLM,k,tNRBA,tLM,printMessage] = fnc_calculate(intLength,s,y,d,...
    ISet,IStartSet,xbarSet,pbarSet,qlbarSet,qnbarSet,R_NRBA,R_LM,nrPartSet,performLM);

%% Plot results
[yplotNRBAVariants,yplotLM,uplot]= fnc_plot(s,y,d,k,cNRBA,cLM,...
    resolution,NRBAlegend);

%% Print computation time
fprintf('Required computation time using\n - LM: \t\t  %.3fs\n',tLM);
for z=1:size(ISet,2);
    fprintf([' - ',NRBAlegend{z},sprintf(': %.3fs\n',tNRBA(z))]);
end
if(printMessage)
    fprintf('For NRBA, choose the number of spline intervals I<=%d.\n',...
        size(cLM,1)-d)
end

%% Save plot data in files
% str = './NRBAexperiment3_approximations';
% fid = fopen(sprintf('%s%s',str,'.txt'),'w');
% fprintf(fid,['yNRBA1\t yNRBA2\t yNRBA3\t yNRBA4\t yLM1\t yLM2\t s\n']);
% fprintf(fid,['%g\t %g\t %g\t %g\t %g\t %g\t %g\n'],[yplotNRBAVariants;yplotLM;uplot]);
% fclose(fid);
% str = './NRBAexperiment3_datapoints';
% fid = fopen(sprintf('%s%s',str,'.txt'),'w');
% fprintf(fid,'y\t s\n');
% fprintf(fid,'%g\t %g\n',[y;s]);
% fclose(fid); 