Run NRBAexperiment1, NRBAexperiment2 or NRBAexperiment3 to perform an 
approximation of data points by B-spline functions whose coefficients are 
determined using the algorithm for nonlinear recursive B-Spline approximation (NRBA) 
in comparison with the solution determined by the Levenberg-Marquardt (LM) 
method as described in

% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).

Some information about the attached MATLAB files and functions:

NRBAexperiment1, NRBAexperiment2 and NRBAexperiment3 are script files in which
various parameters for the approximation can be changed, e.g.:
- The data points (s_p,y_p),p=1,2,...,P that are approximated by B-spline functions
- The desired distance intLength between two neighboring knots of the B-spline knot vector
- The degree d of the B-spline function
- The reciprocals of relative weights of different target criteria for the approximating function determined by NRBA and LM
  which are "f close to data points", "f' close to zero", "f'' close to zero" and "c(f) close to zero". c denotes the nonlinear measurement function
- The number of spline intervals I of the B-spline function in which NRBA can adapt the B-spline function simultaneously

The script files first invoke the function fnc_calculate.m
that performs the approximations and returns the result. Second, they call fnc_plot.m, that plots the data, the knot vector and the approximating functions. Finally, the calculation time for the different approaches
are printed to the console. The plotted data can be written to files. 
 
fnc_calculate.m contains the following functions:
- fnc_calculate performs an approximation using LM followed by approximations using
	NRBA with different parameter settings
- fnc_LM implements the Levenberg-Marquardt method and calls fnc_nlsqfun
- fnc_nlsqfun computes the weighted error vector for the current LM solution and calls fnc_bMat
- fnc_bMat returns a matrix containing values of B-splines

- fnc_NRBA performs a single iteration of NRBA as described in Algorithm 2 of [1] and calls fnc_MPF
- fnc_MPF implements the marginalized particle filter as described in Algorithm 1 of [1]

fnc_BSpl.m returns a B-spline vector and is called by both fnc_calculate and fnc_plot

fnc_plot.m plots the data, the knot vector and the approximation functions determined by LM and NRBA

The files have been tested under MATLAB R2015b 64bit. 
Please let me know if you find bugs or need any help (jens.jauch@kit.edu).