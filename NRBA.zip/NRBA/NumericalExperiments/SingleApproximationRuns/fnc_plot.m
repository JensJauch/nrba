function [yplotNRBAVariants, yplotLMVariants, splot]= fnc_plot...
    (s, y, d, k, cNRBA, cLM, resolution, NRBAlegend)
% This function plots the data points (s_p,y_p) as well as the approximating 
% B-spline functions determined by Levenberg-Marquardt (LM) algorithm and
% nonlinear recursive B-Spline approximation (NRBA) with different values
% of I, whereby I denotes the number of intervals in which the B-spline function 
% can be modified by the marginalized particle filter during an iteration. 
% Furthermore, the knots are indicated by vertical lines. The function returns 
% the s and y values of the plotted functions.
%
%    yplotNRBAVariants: Matrix of y values of plotted functions determined
%    by NRBA
%    yplotLM:          y values of plotted function determined by LM
%    splot:            s values of plotted B-spline function
%    s:                Vector of supporting points s_p of data points (s_p,y_p)
%    y:                Vector of values y_p of data points (s_p,y_p)
%    d:                Degree of B-spline function
%    k:                Knot vector of B-spline function
%    cNRBA:             Matrix of B-spline coefficients determined using RBA
%    cLM:             B-spline coefficients determined using WLS
%    resolution:       Horizontal distance between two neighboring 
%    positions where the B-spline functions are evaluated

figure();
clf
hold on

yplotLMVariants = [];
yplotNRBAVariants = [];
 

%% Plot data points (s_p,y_p)
for mu=1:size(s,2)
  hDP = plot(s(mu),y(mu),'kx');
end

%% Vector of valid spline interval indices
muVec = d+1:size(k,2)-d-1;

%% Plot approximating function determined using LM
hLM = zeros(1,size(cLM,2)); % Vector of handles for legend entries
% Define colors and line styles for the different B-spline functions that
% are plotted   black      gray
colors = {'k',[127/255,127/255,127/255]};

for i=1:size(cLM,2)

    yplotLM = [];
    if(isfinite(cLM(1,i))) % If LM has been performed
        for mu=1:size(muVec,2)
            % s values for a single interval
            splotInt = max(min(s),k(muVec(mu))):resolution:...
                min(k(muVec(mu)+1),max(s));
            % y values for a single interval
            yplotLMInt = [];
            for j=1:size(splotInt,2)
                yplotLMInt(j) = fnc_BSpl(k,muVec(mu),...
                    splotInt(j),d,0)*cLM(mu:mu+d,i);
            end
            % y values for all intervals
            yplotLM = [yplotLM,yplotLMInt];
            % Plot B-spline function in a single interval
            if(size(splotInt,2)>0)
                hLM(1,i) = plot(splotInt,yplotLMInt,'LineStyle',...
                    '-','Color',colors{i},'Linewidth',1.5);
            end
        end
    end
    yplotLMVariants = [yplotLMVariants;yplotLM]; 
end
%% Plot approximating functions determined using NRBA
hRBA = zeros(1,size(cNRBA,2)); % Vector of handles for legend entries

% Define colors and line styles for the different B-spline functions that
% are plotted     own green              own orange
colors = {[77/255,175/255,74/255],[255/255,160/255,0/255],'r','b'};
lineStyles = {'-','-','-','--'};
% Iterate through all different parameter settings
for i=1:size(cNRBA,2)
    splot = [];
    yplotNRBA = [];
    % Plot a single B-spline function
    for mu = 1:size(muVec,2)
        % s values for a single spline interval
        splotInt = max(min(s),k(muVec(mu))):resolution:...
            min(k(muVec(mu)+1),max(s));
        % s values for all spline intervals
        splot = [splot,splotInt];
        % y values for a single spline interval
        yplotNRBAInt = [];
        for j=1:size(splotInt,2)
            yplotNRBAInt(j) = fnc_BSpl(k,muVec(mu),...
                splotInt(j),d,0)*cNRBA(mu:mu+d,i);
        end
        % y values for all spline intervals
        yplotNRBA = [yplotNRBA,yplotNRBAInt];
        % Plot B-spline function in a single spline interval
        m = mod(i-1,4)+1;
        if(size(splotInt,2)>0)
            hRBA(1,i)= plot(splotInt,yplotNRBAInt,'LineStyle',...
                lineStyles{m},'Color',colors{m},'Linewidth',1.5);
        end
    end
% The y values of all plotted approximation functions using NRBA are saved
% in yplotRBAVariants
yplotNRBAVariants = [yplotNRBAVariants;yplotNRBA];   
end

%% Define axes limits and labels
xlabel('input s')
ylabel('measurement y_{p,1} or function value f(s), respectively')
xlim([k(1)-(k(2)-k(1)),k(end)+(k(end)-k(end-1))]);
limY = get(gca,'YLim'); 

%% Plot knots
if(size(k,2)<200) % If there are too many knots, they are not plotted
    arrayfun(@(breaks) line([breaks breaks],limY,'Color','k',...
        'Linestyle','-.'),k);
end
hK = plot(0,0,'k-.'); % Handle for legend entry

%% Define title and legend
title(['Approximation of data points with B-spline functions determined',...
    ' by LM and NRBA'],'FontWeight','bold')
handles = [];
strings = [];
if (size(hLM,1)>0 && sum(sum(isfinite(cLM)))==size(cLM,1)*size(cLM,2))
    handles=[handles,hLM];
    strings=[strings,{'LM1'},{'LM2'}];
end
if (size(hRBA,1)>0)
    for i=1:size(hRBA,2)
        handles=[handles,hRBA(1,i)];
        strings=[strings,{NRBAlegend{i}}];
    end
end
if (size(hDP,1)>0)
    handles=[handles,hDP];
    strings=[strings,{'data points (s_p,y_{p,1})'}];
end
if (size(hK,1)>0)
    handles=[handles,hK];
    strings=[strings,{'knots'}];
end
legend(handles,strings, 0)
set(gcf,'Color','white')