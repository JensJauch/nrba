Run NRBATrajectoryOptimization to perform a multiobjective optimization of B-spline trajectories
for a given time-discrete velocity reference using the algorithm for nonlinear recursive B-Spline approximation (NRBA) 
in comparison with the solution determined by the Levenberg-Marquardt (LM) method as described in

% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).

Some information about the attached MATLAB files and functions:

NRBATrajectoryOptimization is a script file in which
various parameters for the trajectory optimization can be changed, e.g.:
- The reference points (tTar_p,vTar_p),p=1,2,...,P that are loaded from ReferenTrajectory.mat and serve as target values for the B-spline trajectory optimization
- The temporal distance of neighboring data points, i.e. the temporal resolution of the reference
- The desired temporal distance dtKnots between two neighboring knots of the B-spline knot vector
- The degree d of the B-spline function
- The reciprocals of relative weights of optimization goals for the trajectories v determined by NRBA and LM. The optimization goals read
  "trajectory velocity close to reference", "trajectory acceleration close to zero", "trajectory jerk close to zero" and "electric traction power required for tracking the trajectory close to zero".
- The number of spline intervals I of the B-spline function in which NRBA can adapt the B-spline function simultaneously

The script files first invoke the function fnc_calculateTrajectory.m
that performs the optimizations and returns the result. Second, they call fnc_plotTrajectory.m, that plots the reference, the knot vector and the trajectories as well as the required electric traction power and resulting electric traction energy consumption. 
 
fnc_calculateTrajectory.m contains the following functions:
- fnc_calculateTrajectory performs trajectory optimizations using LM followed by trajectory optimizations using
	NRBA with different parameter settings
- fnc_LM implements the Levenberg-Marquardt method and calls fnc_nlsqfun
- fnc_nlsqfun computes the weighted error vector for the current LM solution and calls fnc_bMat
- fnc_bMat returns a matrix containing values of B-splines

- fnc_NRBATrajectory performs a single iteration of NRBA as described in Algorithm 2 of [1] and calls fnc_MPFTrajectory
- fnc_MPFTrajectory implements the marginalized particle filter as described in Algorithm 1 of [1]

fnc_BSpl.m returns a B-spline vector and is called by both fnc_calculateTrajectory and fnc_plotTrajectory

fnc_plotTrajectory.m plots the reference, the knot vector, the trajectories determined by LM and NRBA as well as the required electric traction power and resulting electric traction energy consumption.

The files have been tested under MATLAB R2015b 64bit. 
Please let me know if you find bugs or need any help (jens.jauch@kit.edu).