% This script performs a B-spline trajectory optimization using
% nonlinear recursive B-spline approximation (NRBA) as described in

% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).

%% Generate a set of data points (s_p,y_p_1), c.f. subsection 3.1 of [1]
% Load set points (tTar,vTar) of temporal velocity reference
load('ReferenceTrajectory.mat');
% Define subset of reference that will be used for as input for optimization
tMin = 300;
tMax = 700;
% Define temporal distance of neighboring data points, i.e. the temporal
% resolution of reference. 
dtIteration = 0.25;
% Define data points for trajectory optimization using the notation from
% data approximation
s = max(tMin,min(tTar)):dtIteration:min(tMax,max(tTar));
y = interp1(tTar,vTar,s,'linear','extrap');
% Road slope vector. For simplicity, slope assumed as zero.
slope = zeros(size(y)); % Road slope stated in percent

%% Load mathematical model of electric traction power which is used for
% energetic optimization of trajectories
load('kernelModel.mat');

%% Parameters for B-spline function f(s)
d = 3; % degree of the B-spline function, d>=1
% Temporal distance between two neighboring knots, i.e. desired interval 
% length (>0), i.e.  If the set of data points is chosen such that a shift operation by
% more than d+1 elements has to be performed, the knots of the knot vector 
% computed in fnc_calculate will not be equidistant.
dtKnots = 2;

%% Parameters for nonlinear recursive B-spline approximation (NRBA)
% ...Set are vectors whose i-th component is a parameter value that will be 
% used in the i-th run of NRBA.
% ISet is a vector that contains different numbers of spline intervals I.
ISet = [1,1,1,1];
% IStartSet is a vector that contains different values IStart which denote 
% the spline interval to which the first data point will belong. IStart=1 
% is the first spline interval and IStart=I the last spline interval.
% % IStart=1,2,...,I corresponds to mu = d+1,...,J with J=d+I in [1].
IStartSet = [1,1,1,1];
% xbarSet contains different initial values xbar for estimated spline 
% coefficients. For xbar=NaN, xbar equals y_p_1 or a current coefficient
% estimate
xbarSet = [NaN,NaN,NaN,NaN]; 
% pbarSet contains different initial values pbar for the main diagonal of 
% the covariance matrix of a posteriori error P_plus
pbarSet = [15,15,15,15];
% qlbarSet contains different values qlbar for the main diagonal of the 
% covariance matrix of linear process noise Ql
qlbarSet = 0.5*[1e-2,1e-2,1e-2,1e-2];
% qnbarSet contains different values qbar for the main diagonal of the 
% covariance matrix of nonlinear process noise Qn
qnbarSet = [0.5,0.5,0.5,0.5];
% nrPartSet is a vector that contains different numbers of particles nrPart 
nrPartSet = [1000,1000,1000,1000];
% Diagonal matrix with the reciprocals of the relative weights between the
% different target criteria for the approximating B-spline function f(s),
% on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
% zero, f'' close to zero, c(f) close to zero]. c denotes the nonlinear
% measurement function
R_NRBA = [[5,10,1,1e7];...
          [5,10,1,1e4];...
          [5,10,1,5e2];...
          [5,10,1,1e2]]; 

%% Parameters for Levenberg-Marquardt (LM) algorithm
% Diagonal matrix with the reciprocals of the relative weights between the
% different target criteria for the approximating B-spline function f(s),
% on its diagonal, here [f close to data points (s_p,y_p_1), f' close to 
% zero, f'' close to zero, c(f) close to zero]. c denotes the nonlinear
% measurement function
R_LM = [[5,10,1,1e7];...
        [5,10,1,2e4]];  
% The computation time required for LM increases strongly with the number
% of data points and coefficients. The following variable allows to prevent
% applying LM in such cases. 
performLM = false;

%% Parameters for plot function
% Horizontal distance between two neighboring positions where the
% B-splines functions are evaluated
resolution = 0.1;
% Legend entries for plots
NRBAlegend = {['NRBA R4=',sprintf('%i',R_NRBA(1,4))],...
    ['NRBA R4=',sprintf('%i',R_NRBA(2,4))],...
    ['NRBA R4=',sprintf('%i',R_NRBA(3,4))],...
    ['NRBA R4=',sprintf('%i',R_NRBA(4,4))]};
   
%% Perform calculations
[cNRBA,cLM,k,tNRBA,tLM,printMessage] = fnc_calculateTrajectory(dtKnots,s,y,d,...
    ISet,IStartSet,xbarSet,pbarSet,qlbarSet,qnbarSet,R_NRBA,R_LM,nrPartSet,kernelModel,slope,performLM);

%% Plot results
[vplotNRBAVariants, vplotLMVariants, tplot,...
    pplotNRBAVariants,eplotNRBAVariants] = fnc_plotTrajectory...
    (s,y,d,k,cNRBA,cLM,resolution,NRBAlegend,kernelModel,slope);