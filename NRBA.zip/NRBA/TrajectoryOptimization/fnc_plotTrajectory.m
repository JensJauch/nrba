function [vplotNRBAVariants, vplotLMVariants, tplot,...
    pplotNRBAVariants,eplotNRBAVariants]= fnc_plotTrajectory...
    (s, y, d, k, cNRBA, cLM, resolution, NRBAlegend,kernelModel,slope)
% This function plots the data points (s_p,y_p) as well as the approximating 
% B-spline functions determined by Levenberg-Marquardt (LM) algorithm and
% nonlinear recursive B-Spline approximation (NRBA) with different values
% of I, whereby I denotes the number of intervals in which the B-spline function 
% can be modified by the marginalized particle filter during an iteration. 
% Furthermore, the knots are indicated by vertical lines. The function returns 
% the s and y values of the plotted functions.
%
%    yplotNRBAVariants: Matrix of y values of plotted functions determined
%    by NRBA
%    yplotLM:          y values of plotted function determined by LM
%    splot:            s values of plotted B-spline function
%    s:                Vector of supporting points s_p of data points (s_p,y_p)
%    y:                Vector of values y_p of data points (s_p,y_p)
%    d:                Degree of B-spline function
%    k:                Knot vector of B-spline function
%    cNRBA:             Matrix of B-spline coefficients determined using RBA
%    cLM:             B-spline coefficients determined using WLS
%    resolution:       Horizontal distance between two neighboring 
%    positions where the B-spline functions are evaluated
%   kernelModel:  Parameters of mathematical model of electric traction power
%   slope:        Vector of road slope values 

figure();
clf

% Define colors and line styles for the different B-spline functions that
% are plotted     own green              own orange        red blue black    gray
colors = {[77/255,175/255,74/255],[255/255,160/255,0/255],'r','b','k',[127/255,127/255,127/255]};
lineStyles = {'-','-','-','--','-','-'};

ax = zeros(3,1);
ax(1) = subplot(3,1,1);
hold on

%% Define title
title(['Optimization of velocity reference with B-spline trajectories determined',...
    ' by LM and NRBA'],'FontWeight','bold')

vplotLMVariants = [];
aplotLMVariants = [];
vplotNRBAVariants = [];
aplotNRBAVariants = [];
 

%% Plot data points (s_p,y_p)
for mu=1:size(s,2)
  hDP = plot(s(mu),y(mu),'kx');
end

%% Vector of valid spline interval indices
muVec = d+1:size(k,2)-d-1;

%% Plot approximating function determined using LM
hLM = zeros(1,size(cLM,2)); % Vector of handles for legend entries
for i=1:size(cLM,2)
    vplotLM = [];
    aplotLM = [];
    if(isfinite(cLM(1,i))) % If WLS has been performed
        for mu=1:size(muVec,2)
            % s values for a single interval
            tplotInt = max(min(s),k(muVec(mu))):resolution:...
                min(k(muVec(mu)+1),max(s));
            % y values for a single interval
            vplotLMInt = [];
            aplotLMInt = [];
            for j=1:size(tplotInt,2)
                vplotLMInt(j) = fnc_BSpl(k,muVec(mu),...
                    tplotInt(j),d,0)*cLM(mu:mu+d,i);
                aplotLMInt(j) = fnc_BSpl(k,muVec(mu),...
                    tplotInt(j),d,1)*cLM(mu:mu+d,i);
            end
            % y values for all intervals
            vplotLM = [vplotLM,vplotLMInt];
            aplotLM = [aplotLM,aplotLMInt];
            % Plot B-spline function in a single interval
            if(size(tplotInt,2)>0)
                hLM(1,i) = plot(tplotInt,vplotLMInt,'LineStyle',...
                    lineStyles{i+4},'Color',colors{i+4},'Linewidth',1.5);
            end
        end
    end
    vplotLMVariants = [vplotLMVariants;vplotLM]; 
    aplotLMVariants = [aplotLMVariants;aplotLM]; 
end

%% Plot approximating functions determined using NRBA
hRBA = zeros(1,size(cNRBA,2)); % Vector of handles for legend entries

% Iterate through all different parameter settings
for i=1:size(cNRBA,2)
    tplot = [];
    vplotNRBA = [];
    aplotNRBA = [];
    % Plot a single B-spline function
    for mu = 1:size(muVec,2)
        % s values for a single spline interval
        tplotInt = max(min(s),k(muVec(mu))):resolution:...
            min(k(muVec(mu)+1),max(s));
        % s values for all spline intervals
        tplot = [tplot,tplotInt];
        % y values for a single spline interval
        vplotNRBAInt = [];
        aplotNRBAInt = [];
        for j=1:size(tplotInt,2)
            vplotNRBAInt(j) = fnc_BSpl(k,muVec(mu),...
                tplotInt(j),d,0)*cNRBA(mu:mu+d,i);
            aplotNRBAInt(j) = fnc_BSpl(k,muVec(mu),...
                tplotInt(j),d,1)*cNRBA(mu:mu+d,i);
        end
        % y values for all spline intervals
        vplotNRBA = [vplotNRBA,vplotNRBAInt];
        aplotNRBA = [aplotNRBA,aplotNRBAInt];
        % Plot B-spline function in a single spline interval
        m = mod(i-1,4)+1;
        if(size(tplotInt,2)>0)
            hRBA(1,i)= plot(tplotInt,vplotNRBAInt,'LineStyle',...
                lineStyles{m},'Color',colors{m},'Linewidth',1.5);
        end
    end
% The y values of all plotted approximation functions using NRBA are saved
% in yplotRBAVariants
vplotNRBAVariants = [vplotNRBAVariants;vplotNRBA];   
aplotNRBAVariants = [aplotNRBAVariants;aplotNRBA]; 
end

%% Define axes limits and labels
% xlabel('input s')
ylabel('Velocity in m/s')
xlim([k(1)-(k(2)-k(1)),k(end)+(k(end)-k(end-1))]);
limY = get(gca,'YLim'); 

%% Plot knots
if(size(k,2)<200) % If there are too many knots, they are not plotted
    arrayfun(@(breaks) line([breaks breaks],limY,'Color','k',...
        'Linestyle','-.'),k);
end
hK = plot(0,0,'k-.'); % Handle for legend entry

%% Define legend
handles = [];
strings = [];
if (size(hLM,1)>0 && sum(sum(isfinite(cLM)))==size(cLM,1)*size(cLM,2))
    handles=[handles,hLM];
    strings=[strings,{'LM1'},{'LM2'}];
end
if (size(hRBA,1)>0)
    for i=1:size(hRBA,2)
        handles=[handles,hRBA(1,i)];
        strings=[strings,{NRBAlegend{i}}];
    end
end
if (size(hDP,1)>0)
    handles=[handles,hDP];
    strings=[strings,{'reference (t_p,v_p)'}];
end
if (size(hK,1)>0)
    handles=[handles,hK];
    strings=[strings,{'knots'}];
end
legend(handles,strings, 0)

for i=1:size(cNRBA,2)
    for j=1:size(tplot,2)
        inclplotNRBAVariants{i}(j) = interp1(s,slope,tplot(j),'linear','extrap');
        aIncl = single(9.81)*sin(atan(inclplotNRBAVariants{i}(j)/single(100)));
        A = [vplotNRBAVariants(i,j)*kernelModel.normVehV,(aplotNRBAVariants(i,j)+aIncl)*kernelModel.normALgt];
        pplotNRBAVariants{i}(j) = (-kernelModel.PowerOffset + evaluate(A,kernelModel.dictSize,...
           kernelModel.dict,kernelModel.alpha,kernelModel.options.kernelpar,kernelModel.options.M))...
           /kernelModel.normPower/1000;
    end
end

for i=1:size(cLM,2)
    if(isfinite(cLM(1,i))) % If LM has been performed
        for j=1:size(tplot,2)
           inclplotLMVariants{i}(j) = interp1(s,slope,tplot(j),'linear','extrap');
            aIncl = single(9.81)*sin(atan(inclplotLMVariants{i}(j)/single(100)));
            A = [vplotLMVariants(i,j)*kernelModel.normVehV,(aplotLMVariants(i,j)+aIncl)*kernelModel.normALgt];
            pplotLMVariants{i}(j) = (-kernelModel.PowerOffset + evaluate(A,kernelModel.dictSize,...
               kernelModel.dict,kernelModel.alpha,kernelModel.options.kernelpar,kernelModel.options.M))...
               /kernelModel.normPower/1000;
        end
    end
end

for i=1:size(cNRBA,2)
    dtplot = [0,diff(tplot)];
    eplotNRBAVariants{i} = cumsum(pplotNRBAVariants{i}.*dtplot/3600*1000);
end

for i=1:size(cLM,2)
    if(isfinite(cLM(1,i))) % If LM has been performed
        dtplot = [0,diff(tplot)];
        eplotLMVariants{i} = cumsum(pplotLMVariants{i}.*dtplot/3600*1000);
    end
end

ax(2) = subplot(3,1,2);
hold on
if(size(tplot,2)>0)
    plot(tplot,pplotNRBAVariants{1},'LineStyle',...
    lineStyles{1},'Color',colors{1},'Linewidth',1.5);
        plot(tplot,pplotNRBAVariants{2},'LineStyle',...
    lineStyles{2},'Color',colors{2},'Linewidth',1.5);
        plot(tplot,pplotNRBAVariants{3},'LineStyle',...
    lineStyles{3},'Color',colors{3},'Linewidth',1.5);
        plot(tplot,pplotNRBAVariants{4},'LineStyle',...
    lineStyles{4},'Color',colors{4},'Linewidth',1.5);
    if(isfinite(cLM(1,1))) % If LM has been performed
            plot(tplot,pplotLMVariants{1},'LineStyle',...
        lineStyles{5},'Color',colors{5},'Linewidth',1.5);
    end
    if(isfinite(cLM(1,2))) % If LM has been performed
            plot(tplot,pplotLMVariants{2},'LineStyle',...
        lineStyles{6},'Color',colors{6},'Linewidth',1.5);
    end
end
ylabel('El. power in kW')

ax(3) = subplot(3,1,3);
hold on
if(size(tplot,2)>0)
    plot(tplot,eplotNRBAVariants{1},'LineStyle',...
    lineStyles{1},'Color',colors{1},'Linewidth',1.5);
        plot(tplot,eplotNRBAVariants{2},'LineStyle',...
    lineStyles{2},'Color',colors{2},'Linewidth',1.5);
        plot(tplot,eplotNRBAVariants{3},'LineStyle',...
    lineStyles{3},'Color',colors{3},'Linewidth',1.5);
        plot(tplot,eplotNRBAVariants{4},'LineStyle',...
    lineStyles{4},'Color',colors{4},'Linewidth',1.5);
    if(isfinite(cLM(1,1))) % If LM has been performed
            plot(tplot,eplotLMVariants{1},'LineStyle',...
        lineStyles{5},'Color',colors{5},'Linewidth',1.5);
    end
    if(isfinite(cLM(1,2))) % If LM has been performed
            plot(tplot,eplotLMVariants{2},'LineStyle',...
        lineStyles{6},'Color',colors{6},'Linewidth',1.5);
    end
end
ylabel('El. energy in Wh')

xlabel('Time in s')
linkaxes(ax,'x')
set(gcf,'Color','white')

end

function y_est = evaluate(x, dictSize, dict, alpha, kernelpar, M) % evaluate the algorithm
    if dictSize>0
        k = single(kernel(dict(1:dictSize,:),x, kernelpar, M));
        y_est = k'*alpha;
    else
        y_est = single(zeros(size(x,1),1));
    end
end

% Calculate the kernel matrix for two data sets.
% Author: Steven Van Vaerenbergh, 2013
%
% This file is part of the kernelModelLow Adaptive Filtering Toolbox for Matlab.
% http://sourceforge.net/projects/kafbox/

function K = kernel(X1,X2, kpar,M)
    K  = single(zeros(M,1));
    dist2 = single(zeros(M,1));
    mat2 = single(zeros(M,1));
    N1 = size(X1,1);
    norms1 = single(sum(X1.^2,2));
    norms2 = single(sum(X2.^2,2));
    mat1 = norms1;
    mat2(1:N1) = norms2;
    %
    dist2(1:N1) = mat1(1:N1) + mat2(1:N1) - 2*X1*X2';	% full distance matrix
    K(1:N1) = exp(-dist2(1:N1)/(single(2)*kpar^2));
end % EoF kernel