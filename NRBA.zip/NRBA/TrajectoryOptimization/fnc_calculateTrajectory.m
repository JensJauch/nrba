function [cNRBA,cLM,knotVecGlobal,tNRBA,tLM,printMessage] = fnc_calculateTrajectory...
    (intLength,s,y,d,ISet,IStartSet,xbarSet,pbarSet,qlbarSet,qnbarSet,R_NRBA,R_LM,nrPartSet,kernelModel,slope,performLM)
% This function perfoms the trajectory optimization with a reference (s_p,y_p) using
% the Levenberg-Marquardt method and the nonlinear recursive B-Spline
% approximation (NRBA) method as described in
%
% [1]: Jens Jauch, Felix Bleimund, Michael Frey, Frank Gauterin: 
%      An Iterative Method Based on the Marginalized Particle Filter for
%      Nonlinear B-spline Data Approximation and Trajectory Optimization;
%      Mathematics (2019).
%
% For NRBA, multiple approximations are performed with different settings 
% defined by the elements in the vectors ISet, IStartSet, xbarSet, pbarSet and
% qbarSet. For each approximation performed by LM or NRBA, 
% respectively, the function returns both the determined function 
% coefficients and knot vector as well as the required computation time.
% 
% cNRBA:         Matrix of B-spline coefficients determined using NRBA with 
% different parameter settings which vary along the columns
% cLM:           B-spline coefficients determined using LM with 
% different parameter settings which vary along the columns
% knotVecGlobal: Knot vector of B-spline aproximation functions
% tNRBA:         Vector that contains the computation time for each NRBA run
% tLM:           Computation time required by LM
% printMessage:  Boolean variable that indicates if the number of spline 
% intervals I has been limited for a run of RBA because I had been chosen 
% too large
% intLength:     Desired distance between two neighboring knots
% s:             Vector of supporting points s_p of data points (s_p,y_p)
% y:             Vector of values y_p of data points (s_p,y_p)
% d:             Degree of B-spline function
% ISet:          Vector that contains d
% IStartSet      Vector that contains different values IStart which denote 
% the spline interval to which the first data point will belong
% xbarSet:       Vector that contains different initial values xbar for 
% estimated spline coefficients
% pbarSet:       Vector that contains different initial values pbar for the 
% main diagonal of the covariance matrix of a posteriori error P_plus
% qlbarSet:      Vector that contains different values qlbar for the main 
% diagonal of the covariance matrix of process noise Ql
% qnbarSet:      Vector that contains different values qnbar for the main 
% diagonal of the covariance matrix of process noise Qn
% R_NRBA:        Vector that contains the reciprocals of relative weights 
% between the different target criteria 
% R_LM:          Vector that contains the reciprocals of relative weights 
% between the different target criteria 
% nrPartSet:     Vector that contains different numbers of particles nrPart 
% kernelModel:  Parameters of mathematical model of electric traction power
% slope:        Vector of road slope values 

%% Compute the global knot vector with equidistant knots if possible
% Sort the data and compute the distance between neigboring points
sSorted = sort(s);
ds = sSorted(2) - sSorted(1);
% Add 10 times the machine epsilon to the fraction intLength/ds before 
% rounding in order to avoid undesired results of the floor operation caused 
% by round-off-errors 
pointsPerInterval = floor(intLength/ds+10*eps(intLength/ds));
% Compute the necessary inner knots of the knot vector
innerKnots = sSorted(1)-ds/2:pointsPerInterval*ds:sSorted(end)+ds/2;
if (sSorted(end)>innerKnots(end))
    innerKnots = [innerKnots,innerKnots(end)+intLength];
end
% If the data points are not equidistant and there is a large gap between
% some neighboring data points, it might be necessary to adapt 
% the number and position of the knots in the global knot vector such that 
% appropriate additional knots are specified if fnc_NRBA performs a shift 
% operation by more than d+1 elements. In case of a large gap, the
% following lines remove redundant knots and increase the distance of knots
% around a large gap of s_p in the data set. 

% Counter for the number of neighboring spline intervals without any data
% points
neighbIntervWithoutData = 0;
% Iterate through the inner knots
for i = 1:size(innerKnots,2)-1
    anyPointInInterval = false;
    % Iterate through the data set
    for p = 1:size(s,2)
        if(sSorted(p)>=innerKnots(i) && sSorted(p)<innerKnots(i+1))
            anyPointInInterval = true;
            % If there has been no data in more than d previous spline
            % intervals but there is data in the current spline interval,
            % the knots of the first d-1 empty spline intervals are adapted
            % using linear interpolation between the right border of the
            % last spline interval with data
            % (knots(i-neighbInterWithoutData)) and the left border of the 
            % current spline interval (knots(i))
            if(neighbIntervWithoutData>d)
                m = i-neighbIntervWithoutData+1:i-1;
                for n = 1:size(m,2);
                    if(n<=d-1)
                        % Adapt the position of the first d-1 knots
                        innerKnots(m(n)) = ...
                            innerKnots(i-neighbIntervWithoutData)+...
                            n*(innerKnots(i)-...
                            innerKnots(i-neighbIntervWithoutData))/d;
                    else
                        % Overwrite redundant knots with NaN to indicate 
                        % that they have to be removed
                        innerKnots(m(n)) = NaN;
                    end
                end
            end
            neighbIntervWithoutData = 0;
            break;
        end
    end
    if(~anyPointInInterval)
        neighbIntervWithoutData = neighbIntervWithoutData+1;
    end
end
% Remove redundant knots
innerKnots = innerKnots(~isnan(innerKnots));
% Compute additional knots for the beginning and end of the global knot
% vector
knotsBeg = innerKnots(1)-d*intLength:intLength:innerKnots(1)-intLength;
knotsEnd = innerKnots(end)+intLength:intLength:innerKnots(end)+d*intLength;
% Compose the global knot vector whose elements are used to initialize the
% knot vector for fnc_NRBA and to provide additional knots in case of shift
% shift operations
knotVecGlobal = [knotsBeg,innerKnots,knotsEnd];

%% Perform approximation using Levenberg-Marquardt (LM) algorithm
tic;
% Coefficients of B-spline function determined by LM
cLM = NaN*ones(size(knotVecGlobal,2)-d-1,2); 
if(performLM)
    cLM(1:end/2) = fnc_LM(s,y,knotVecGlobal,d,diag(R_LM(1,:)),y(1),kernelModel,slope);
    cLM((end/2)+1:end) = fnc_LM(s,y,knotVecGlobal,d,diag(R_LM(2,:)),y(1),kernelModel,slope);
end
tLM = toc/2; % Computation time required by LM

%% Perform approximation using nonlinear recursive B-spline approximation (NRBA)
% Intialize matrix cNRBA. Each column contain the coefficients of the 
% B-spline function determined by RBA. The parameter settings of RBA vary 
% along the rows of cNRBA
cNRBA = NaN*ones(size(knotVecGlobal,2)-d-1,size(ISet,2)); 
% Vector that stores the computation time required by NRBA with different 
% settings
tNRBA = zeros(1,size(ISet,2)); 
% Print a message that the number of spline intervals I has been limited
% for a run of NRBA because I had been chosen too large
printMessage = false;
% Iteration through all different components of ISet
for i=1:size(ISet,2)
    % Determine the number of spline intervals I and the spline interval 
    % IStart to which the first data points will belong. 
    I = ISet(i);
    if(I>size(knotVecGlobal,2)-2*d-1)
        printMessage = true;
        I = size(knotVecGlobal,2)-2*d-1;
    end
    IStart = min(IStartSet(i),I);
    
    %% Initialize the knot vector knotVecNRBA that is used by NRBA and 
    % contains only knots for I intervals.
    J = d+I; % Total number of B-splines
    K = d+J+1; % Total number of knots
    knotVecNRBA = NaN*ones(1,K);
    % Spline interval of first data point
    mu_s1 = find(knotVecGlobal<=s(1),1,'last');
    leftPart = max(1,mu_s1-d-IStart+1):mu_s1;
    rightPart = mu_s1+1:min(mu_s1-d-IStart+K,size(knotVecGlobal,2));
    knotVecNRBA([max(1,(-(size(leftPart,2)-1)+d+IStart)):d+IStart,...
        d+IStart+1:min(d+IStart+1+size(rightPart,2)-1,K)]) ...
        = knotVecGlobal([leftPart,rightPart]);

    % Initialize the a posteriori state estimation (estimated B-spline 
    % coefficients)
    if(isfinite(xbarSet(i)))
        xVecHatPlus = xbarSet(i)*ones(J,1); 
    else
        xVecHatPlus = y(1)*ones(J,1); 
    end
    % Initialize the covariance matrix of a posteriori estimation error
    P_plus = pbarSet(i)*eye(d+I); 
    
    %% Initialization of marginalized particle filter (MPF) quantities
    xnp = zeros(size(xVecHatPlus,1),nrPartSet(i)); % Nonlinear states
    xlp = zeros(size(xVecHatPlus,1),nrPartSet(i)); % Conditionally linear Gaussian states
    CHOL = chol(P_plus);
    for zz = 1:nrPartSet(i)
        xnp(:,zz) = xVecHatPlus + CHOL*randn(J,1);  
        xlp(:,zz) = xVecHatPlus;          
    end
   
    knotVecNRBAOld = knotVecNRBA;
    % Row of cNRBA where xVecHatPlus(1) will be stored at the end of the
    % approximation
    positionxVecHatPlus = 1;
    % Start time measurement
    tic;
    %% Iterate through all data points
    for p=1:size(s,2)+1 %% Since MPF performs measurement update before time update
        sVal = s(max(1,min(p,size(s,2)))); % Value for MPF time update
        sValOld = s(max(1,min(p-1,size(s,2)))); % Value for MPF measurement update
        yValOld = y(max(1,min(p-1,size(s,2)))); % Value for MPF measurement update
        slopeValOld = slope(max(1,min(p-1,size(s,2)))); % Value for MPF measurement update
        sigma = 0;
        % KnotVecbar contains the knots that are needed by fnc_NRBA in case
        % of a shift operation        
        knotVecbar = NaN*ones(1,size(knotVecNRBA,2));
        
        % Determine sigma and new knot vector for MPF time update
        if(sVal>=knotVecNRBA(J+1))
            % A right shift will be performed by fnc_NRBA. Determine the 
            % shift variable sigma and copy the knots that will be needed 
            % by fnc_NRBA for shift operation from the knotVecGlobal to 
            % knotVecbar
            if(sVal>=knotVecNRBA(K))
                sigma = d+1;
                knotVecbar(K-sigma+1:K) = knotVecGlobal(find(...
                    knotVecGlobal>sVal,sigma,'first'));
            else
                sigma=find(knotVecNRBA<=sVal,1,'last')-J;
                knotVecbar(K-sigma+1:K) = knotVecGlobal(find(...
                    knotVecGlobal>knotVecNRBA(end),sigma,'first'));
            end
        elseif(sVal<knotVecNRBA(d+1))
            % A left shift will be performed by fnc_NRBA. Determine the 
            % shift variable sigma and copy the knots that will be needed 
            % by fnc_NRBA for shift operation from the knotVecGlobal to 
            % knotVecbar
            if(sVal<knotVecNRBA(1))
                sigma = -(d+1);
                knotVecbar(1:-sigma) = ...
                    knotVecGlobal(find(knotVecGlobal<=sVal,-sigma,'last'));
            else
                sigma=find(knotVecNRBA<=sVal,1,'last')-(d+1);
                knotVecbar(1:-sigma) = knotVecGlobal(...
                    find(knotVecGlobal<knotVecNRBA(1),-sigma,'last'));
            end
        end

         % Determine sigma and new knot vector for MPF measurement update
        if(sValOld>=knotVecNRBAOld(J+1))
            % A right shift will be performed by fnc_NRBA. Determine the 
            % shift variable sigma and copy the knots that will be needed 
            % by fnc_NRBA for shift operation from the knotVecGlobal to 
            % knotVecbar
            if(sValOld>=knotVecNRBAOld(K))
                sigmaOld = d+1;
            else
                sigmaOld=find(knotVecNRBAOld<=sValOld,1,'last')-J;
            end
            % Copy coefficient estimates in xHatVecPlus that will be
            % overwritten during the shift operation to cNRBA
            muglobal = find(knotVecGlobal<=sValOld,1,'last');
            cVec = max(1,muglobal-I-sigmaOld-d+1):muglobal-I-1-d+1;
            if(size(cVec,2)>0)
                cNRBA(cVec,i) = xVecHatPlus(sigmaOld-size(cVec,2)+1:sigmaOld);
            end
            % Update the row of cNRBA where xVecHatPlus(1) will be stored at 
            % the end of the approximation
            positionxVecHatPlus = max(1,min(size(cNRBA,1)-(J-1),muglobal-I));
        elseif(sVal<knotVecNRBAOld(d+1))
            % A left shift will be performed by fnc_NRBA. Determine the 
            % shift variable sigma and copy the knots that will be needed 
            % by fnc_NRBA for shift operation from the knotVecGlobal to 
            % knotVecbar
            if(sValOld<knotVecNRBAOld(1))
                sigmaOld = -(d+1);
            else
                sigmaOld=find(knotVecNRBAOld<=sValOld,1,'last')-(d+1);
            end
            % Copy coefficient estimates in xHatVecPlus that will be
            % overwritten during the next shift operation to cNRBA
            muglobal = find(knotVecGlobal<=sValOld,1,'last');
            cVec = muglobal+J-d:min(muglobal+I-1-sigmaOld,size(cNRBA,1));
            if(size(cVec,2)>0)
                cNRBA(cVec,i) = xVecHatPlus(J+sigmaOld+1:J);
            end
            % Update the row of cNRBA where xVecHatPlus(1) will be stored at 
            % the end of the approximation
            positionxVecHatPlus = max(1,min(muglobal-d,size(cNRBA,1)-J+1));
        end
        
        % Determine initial values for coefficient estimates
        if(isfinite(xbarSet(i)))
            initval = xbarSet(i);
        else
            if(sigma>=0)
                initval = xVecHatPlus(end);
            else
                initval = xVecHatPlus(1);
            end
        end
        
        % Perform one NRBA iteration
        [xVecHatPlus,xlp,xnp,P_plus,knotVecNRBANew] = ...
        fnc_NRBATrajectory(knotVecNRBA,xlp,xnp,P_plus,...
        diag(R_NRBA(i,1:4)),sVal,sValOld,[yValOld;0;0;0],knotVecbar,...
        initval,pbarSet(i),qlbarSet(i),qnbarSet(i),nrPartSet(i),kernelModel,slopeValOld);

        knotVecNRBAOld = knotVecNRBA;
        knotVecNRBA = knotVecNRBANew;
    end
    % Copy all elements of xVecHatPlus to cNRBA
    if(p>1)
        cNRBA(positionxVecHatPlus+[0:J-1],i) = xVecHatPlus;
    end
    % Save the required computation time of the NRBA run
    tNRBA(i) = toc;
end
end

function cLM = fnc_LM(s,y,k,d,R,xbar,kernelModel,slope) 
% This function perfoms the approximation of data points (s_p,y_p) using
% the Levenberg-Marquardt method.
% 
% cLM:          B-spline coefficients determined using LM
% s:            Vector of supporting points s_p of data points (s_p,y_p)
% y:            Vector of values y_p of data points (s_p,y_p)
% k:            Global knot vector of B-spline aproximation function
% d:            Degree of B-spline function
% R:            Vector that contains the reciprocals of relative weights 
% between the different target criteria 
% xbar:         initial value xbar for estimated spline coefficients
% kernelModel:  Parameters of mathematical model of electric traction power
% slope:        Vector of road slope values 

K = size(k,2); % Number of knots
J = K-d-1; % Number of B-splines
x0 = xbar*ones(J,1); % Initial coefficient vector for LM
fun = @(x) nlsqfun(x,s,y,k,d,R,kernelModel,slope); % Error function handle for NWLS approximation

% Perform NWLS approximation using LM
options = optimoptions(@lsqnonlin);
options.Algorithm = 'levenberg-marquardt';
cLM = lsqnonlin(fun,x0,[],[],options);
end

function error = nlsqfun(x,s,y,k,d,R,kernelModel,slope)
% This function provides the current weighted unsquared error between measurements
% and the B-spline function values resulting from the current coefficient vector 
% determined using the Levenberg-Marquardt method.
% 
% x:            B-spline coefficients vector
% s:            Vector of supporting points s_p of data points (s_p,y_p)
% y:            Vector of values y_p of data points (s_p,y_p)
% k:            Global knot vector of B-spline aproximation function
% d:            Degree of B-spline function
% R:            Vector that contains the reciprocals of relative weights 
% between the different target criteria
% kernelModel:  Parameters of mathematical model of electric traction power
% slope:        Vector of road slope values 

val = zeros(4*size(y,2),1); 

% Compute value of B-spline function and its first two derivatives at each
% s_p
C = [fnc_bMat(s, k,d,0);fnc_bMat(s, k,d,1);fnc_bMat(s, k,d,2)];
val(1:3*size(y,2),1) = C*x;

% Compute value of nonlinear measurement function at each s_p
for p = 1:size(y,2)
    mu = find(k<=s(p),1,'last');
    val(3*size(y,2)+p,1) = fnc_MPF_nonLinModelFncPowerModel(fnc_BSpl(k,mu,s(p),d,0),...
        fnc_BSpl(k,mu,s(p),d,1),x(mu-d:mu),kernelModel,slope(p));
end

% Compute weighted error (not squared) between B-spline function and measurement
error = (val - [y';zeros(size(s,2),1);zeros(size(s,2),1);zeros(size(s,2),1)])...
./[sqrt(R(1,1))*ones(size(s,2),1);sqrt(R(2,2))*ones(size(s,2),1);...
    sqrt(R(3,3))*ones(size(s,2),1);sqrt(R(4,4))*ones(size(s,2),1)];
end

function bMat = fnc_bMat(s,k,d,r)
% This function returns the design matrix for the r-th derivative of a 
% B-spline function of degree d with knot vector k that is needed by 
% function fnc_nlsqfun
%
% bMat: B-spline design matrix that contains the vector of B-splines for 
% s_p in row p, possibly preceeded and followed by zeros
% s:    Vector of supporting points s_p of data points (s_p,y_p)
% k:    Knot vector of B-spline function
% d:    Degree of B-spline function
% r:    Order of derivative of B-spline function

% Compute the design matrix for the B-spline function including its first 
% two derivatives
bMat = zeros(size(s,2),size(k,2)-d-1);
for p=1:size(s,2)
    % Determine index mu of the spline interval to which s_p belongs
    mu = find(k<=s(p),1,'last');
    bMat(p,mu-d:mu) = fnc_BSpl(k,mu,s(p),d,r); % Insert B-spline vector
end
end