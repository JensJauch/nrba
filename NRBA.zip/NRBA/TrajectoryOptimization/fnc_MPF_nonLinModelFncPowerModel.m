function Power = fnc_MPF_nonLinModelFncPowerModel(b0,b1,c,kernelModel,slope)
% This function implements the nonlinear measurement function using the
% mathematical model for the electric traction power
%
% Power:    Estimated electric traction power
% b:        B-spline vector of approximating function
% c:        Coefficient vector of approximating function
    
v = b0*c; % Planned vehicle velocity
dv = b1*c; % Planned vehicle acceleration

% Acceleration value including effect of road slope
aSensor = dv+single(9.81)*sin(atan(slope/single(100)));
% Model input
A = [ v*single(kernelModel.normVehV), aSensor*single(kernelModel.normALgt)]';
% Model evaluation
Power =  (single(evaluate(A', kernelModel.dictSize, kernelModel.dict, kernelModel.alpha, kernelModel.options.kernelpar, kernelModel.options.M )) ...
    - single(kernelModel.PowerOffset))/single(kernelModel.normPower)/single(1000); 
end

function y_est = evaluate(x, dictSize, dict, alpha, kernelpar, M) % evaluate the algorithm
    if dictSize>0
        k = single(kernel(dict(1:dictSize,:),x, kernelpar, M));
        y_est = k'*alpha;
    else
        y_est = single(zeros(size(x,1),1));
    end
end

% Calculate the kernel matrix for two data sets.
% Author: Steven Van Vaerenbergh, 2013
%
% This file is part of the Kernel Adaptive Filtering Toolbox for Matlab.
% http://sourceforge.net/projects/kafbox/

function K = kernel(X1,X2, kpar,M)
    K  = single(zeros(M,1));
    dist2 = single(zeros(M,1));
    mat2 = single(zeros(M,1));
    N1 = size(X1,1);
    norms1 = single(sum(X1.^2,2));
    norms2 = single(sum(X2.^2,2));
    mat1 = norms1;
    mat2(1:N1) = norms2;
    %
    dist2(1:N1) = mat1(1:N1) + mat2(1:N1) - 2*X1*X2';	% full distance matrix
    K(1:N1) = exp(-dist2(1:N1)/(single(2)*kpar^2));
end